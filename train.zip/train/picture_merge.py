import cv2
import os
import random
def ShapeDetection(path):
    contours,hierarchy = cv2.findContours(path,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)  #寻找轮廓点
    print(len(contours))
    info=dict()
    for obj in contours:
        area = cv2.contourArea(obj)  # 计算轮廓内区域的面积
        # cv2.drawContours(imgContour, obj, -1, (255, 0, 0), 4)  # 绘制轮廓线
        perimeter = cv2.arcLength(obj, True)  # 计算轮廓周长
        approx = cv2.approxPolyDP(obj, 0.02 * perimeter, True)  # 获取轮廓角点坐标
        CornerNum = len(approx)  # 轮廓角点的数量
        x, y, w, h = cv2.boundingRect(approx)  # 获取坐标值和宽度、高度
        info[area]=[x,y,w,h]

def mask_detection(mask_jpg):
    mask_gray = cv2.cvtColor(mask_jpg, cv2.COLOR_BGR2GRAY)
    ret, mask = cv2.threshold(mask_gray, 200, 255, cv2.THRESH_BINARY)
    return mask

def handle_img(imgdir,img_path):
    imgs = os.listdir(imgdir)
    imgNum = len(imgs)
    print(imgNum)
    image_ori = os.listdir(img_path)
    image_Num = len(image_ori)
    print(image_Num)
    # mask_jpg = cv2.imread(mask_path)
    # mask=mask_jpg[:,:,0]
    # mask[mask<150]=0
    # mask[mask>=150]=255
    # mask_gray = cv2.cvtColor(mask_jpg, cv2.COLOR_BGR2GRAY)
    # ret, mask = cv2.threshold(mask_gray, 200, 255, cv2.THRESH_BINARY)
    # mask_inv = cv2.bitwise_not(mask)
    # cv2.imshow('image',mask)
    # cv2.waitKey(0)
    for i in range(imgNum):
        img = cv2.imread(imgdir + "/" + imgs[i])
        # try:
        mask_jpg = cv2.imread(mask_path + '/' + imgs[i])
        mask = make_detection(mask_jpg)
        x, y = mask_jpg.shape[0:2]
        img_2 = cv2.resize(img, (int(x * 2), int(y * 2)))
        mask_2 = cv2.resize(mask, (int(x * 2), int(y * 2)))
        mask_inv = cv2.bitwise_not(mask)
        mask_2_inv = cv2.bitwise_not(mask_2)
        # rows, cols, channels = img.shape
        rows_2, cols_2, channels_2 = img_2.shape
        # except Exception:continue
        for j in range(0,30):
            oriImg = cv2.imread(img_path + "/" + image_ori[j])

            width,height,_=oriImg.shape
            # print(width,rows)
            # try:
            print(width,rows_2,height,cols_2)
            # y = random.randint(0,width-rows_2)
            #     # print(y)
            # x=random.randint(0,height-cols_2)
            y = random.randint(0, width)
            x = random.randint(0, height)
            roi = oriImg[y:(y+rows_2), x:(x+cols_2)]
            # except Exception:
            #     continue
            # print(imgs[i])
            orimg_bg=cv2.bitwise_and(roi,roi,mask=mask_2_inv)

            img_fg=cv2.bitwise_and(img,img,mask=mask_2)
            # y,x,z=img_fg.shape
            # new_shape=(int(img_fg.shape[0]),int(img_fg.shape[1]*1.2))
            # larger_img=cv2.pyrUp(img_fg,dstsize=new_shape)
            # cv2.imshow('image', img_fg)
            # cv2.waitKey(0)
            dest=cv2.add(img_fg,orimg_bg)
            oriImg[y:(y+rows_2),x:(x+cols_2)]=dest
            # cv2.imshow('image', oriImg)
            # cv2.waitKey(0)
            cv2.imwrite('/media/hxzh02/SB@home/hxzh/wugaoso_yiwu_train/data_aug/'+str(i)+image_ori[j],oriImg)
            # except Exception:
            #     continue
            # oriImg.paste(img, (image[0]-102, image[1]-102))
            # if image[0]:
            #     oriImg.paste(img, (random.randint(0, image[0] - 102), random.randint(0, image[0] - 102)))
            # else:
            #     oriImg.paste(img, (random.randint(0, image[1] - 102), random.randint(0, image[1] - 102)))
            # oriImg.show()
            # oriImg1 = oriImg.convert('RGB')
            # oriImg1.save("F:/Download/sign2_data" + "/" + str(i) + ".jpg")


imgdir = "/media/hxzh02/SB@home/hxzh/wugaoso_yiwu_train/biubiubiu"
img_path = "/media/hxzh02/SB@home/hxzh/wugaoso_yiwu_train/train"
mask_path='/media/hxzh02/SB@home/hxzh/wugaoso_yiwu_train/cat'
# save_path='/media/hxzh02/SB@home/hxzh/wugaoso_yiwu_train/trial'
handle_img(imgdir,img_path)

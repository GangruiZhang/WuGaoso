import os
from tqdm import tqdm
def Compare_txt(txt_path1,txt_path2):
    txt_file1=os.listdir(txt_path1)
    txt_file2=os.listdir(txt_path2)
    for i,name in enumerate(tqdm(txt_file1)):
        txt_File1=open(os.path.join(txt_path1,name))
        txt_list1=txt_File1.readlines()
        txt_File2=open(os.path.join(txt_path2,name))
        txt_list2=txt_File2.readlines()




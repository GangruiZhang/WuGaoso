import cv2
import os
import random
import numpy as np
def ShapeDetection(path):
    contours,hierarchy = cv2.findContours(path,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)  #寻找轮廓点
    print(len(contours))
    info=[0]*4
    for obj in contours:
        area = cv2.contourArea(obj)  # 计算轮廓内区域的面积
        # cv2.drawContours(imgContour, obj, -1, (255, 0, 0), 4)  # 绘制轮廓线
        perimeter = cv2.arcLength(obj, True)  # 计算轮廓周长
        approx = cv2.approxPolyDP(obj, 0.02 * perimeter, True)  # 获取轮廓角点坐标
        CornerNum = len(approx)  # 轮廓角点的数量
        x, y, w, h = cv2.boundingRect(approx)  # 获取坐标值和宽度、高度
        info[0:4]=x-10,y-10,w+20,h+20
    return info

"二值化处理"
def mask_detection(img,mask_jpg):
    mask_gray = cv2.cvtColor(mask_jpg, cv2.COLOR_BGR2GRAY)
    ret, mask = cv2.threshold(mask_gray, 200, 255, cv2.THRESH_BINARY)
    info=ShapeDetection(mask)
    x,y,w,h=info[0:4]
    mask=mask[y:(y+h),x:(x+w)]
    img = img[y:(y + h), x:(x + w)]
    return [img,mask]

"放大缩小图片的"
def resize_2(img,m):
    img_new=cv2.resize(img,(int(img.shape[1]*m),int(img.shape[0]*m)))
    return img_new

"对掩膜和图片进行放大和缩小的"
def expand(mask,img,oriImg,num):
    y,x,_=oriImg.shape
    y_i,x_i,_=img.shape
    if y*x>=num and y_i*x_i<9100:
        img=resize_2(img,3.5)
        mask=resize_2(mask,3.5)
    elif y*x>=num and y_i*x_i>=9100:
        img=resize_2(img,2.5)
        mask=resize_2(mask,2.5)
    else:
        img=resize_2(img,1)
        mask=resize_2(mask,1)
    mask_inv=cv2.bitwise_not(mask)
    return mask,img,mask_inv


def handle_img(imgdir,img_path):
    imgs = os.listdir(imgdir)
    imgNum = len(imgs)
    print(imgNum)
    image_ori = os.listdir(img_path)
    image_Num = len(image_ori)
    print(image_Num)

    img_aver=[]
    for i in range(imgNum):
        img = cv2.imread(imgdir + "/" + imgs[i])
        # cv2.namedWindow('img')
        # cv2.imshow('img', img)
        # cv2.waitKey(0)
        # print(img.shape)
        try:
            mask_jpg = cv2.imread(mask_path + '/' + imgs[i])
            img,mask = mask_detection(img,mask_jpg)
        except Exception:continue
        # img_aver.append(img.shape[0]*img.shape[1])
    #     # img_aver_1.append(img.shape[1])
    #     # if img.shape[0]<136:
    #     #     img = resize_2(img,3)
    #     #     mask = resize_2(mask,3)
    #     # else:
    #     #     img=resize_2(img,1)
    #     #     mask=resize_2(mask,1)
    #     # mask=ShapeDetection(mask)
    #     # mask_inv = cv2.bitwise_not(mask)
    #     # rows, cols, channels = img.shape
    #     # rows, cols, channels = img.shape
    #     # except Exception:continue
    #     # shape=[]
        for j in range(0,10):
            oriImg = cv2.imread(img_path + "/" + image_ori[j])
            # shape.append(oriImg.shape[0]*oriImg.shape[1])
            mask1,img1,mask_inv1=expand(mask, img,oriImg,5908940)
            rows, cols, channels = img1.shape
            height,width,_=oriImg.shape
            # print(width,rows,height,cols)
            # except Exception:
            #     continue
            # print(imgs[i])
            try:
                y = random.randint(int(0.7*height), height - rows)
                x = random.randint(0, width - cols)
            except Exception:continue
            roi = oriImg[y:(y + rows), x:(x + cols)]
            img_fg=cv2.bitwise_and(img1,img1,mask=mask1)
            orimg_bg = cv2.bitwise_and(roi, roi, mask=mask_inv1)
            # y,x,z=img_fg.shape
            # new_shape=(int(img_fg.shape[0]),int(img_fg.shape[1]*1.2))
            # larger_img=cv2.pyrUp(img_fg,dstsize=new_shape)
            # cv2.imshow('image', img_fg)
            # cv2.waitKey(0)
            dest=cv2.add(img_fg,orimg_bg)
            oriImg[y:(y+rows),x:(x+cols)]=dest
            # cv2.imshow('image', oriImg)
            # cv2.waitKey(0)
            cv2.imwrite('/media/hxzh02/SB@home/hxzh/wugaoso_yiwu_train/data_aug/'+str(i)+image_ori[j],oriImg)


imgdir = "/media/hxzh02/SB@home/hxzh/wugaoso_yiwu_train/biubiubiu"
img_path = "/media/hxzh02/SB@home/hxzh/wugaoso_yiwu_train/train"
mask_path='/media/hxzh02/SB@home/hxzh/wugaoso_yiwu_train/cat'
# save_path='/media/hxzh02/SB@home/hxzh/wugaoso_yiwu_train/trial'
handle_img(imgdir,img_path)
